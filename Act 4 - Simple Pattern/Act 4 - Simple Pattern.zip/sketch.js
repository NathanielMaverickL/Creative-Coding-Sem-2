function setup() {
  createCanvas(400, 400);
  noLoop();
  background('#e1be32'); 
  noStroke();

  let tileSize = 50;
  for (let y = 0; y < height; y += tileSize) {
    for (let x = 0; x < width; x += tileSize) {
      fill('#255381');
      rect(x, y, tileSize, tileSize, 10); 

      fill('#e1be32');
      ellipse(x + tileSize / 2, y + tileSize / 2, tileSize * 0.6);
    }
  }
}
