let mic;
let amplitude = 0;
let font;
let points = [];
let threshold = 0.015; 

let video;
let handpose;
let hand = null;
let rotationX = 0;
let rotationY = 0;

let zoom = 1;
let lastTouchDist = null;

function preload() {
  font = loadFont('https://cdnjs.cloudflare.com/ajax/libs/topcoat/0.8.0/font/SourceCodePro-Regular.otf');
}

function setup() {
  createCanvas(800, 800, WEBGL); 

  mic = new p5.AudioIn();
  mic.start();

  textFont(font);
  textSize(12);
  textAlign(CENTER, CENTER);

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  handpose = ml5.handpose(video, () => {
    console.log("Handpose model ready");
  });

  handpose.on("predict", results => {
    if (results.length > 0) {
      hand = results[0];
    }
  });

  // Increased density of binary digits
  for (let i = 0; i < 400; i++) {
    let theta = random(TWO_PI);
    let phi = random(PI);
    let x = 120 * sin(phi) * cos(theta);
    let y = 120 * sin(phi) * sin(theta);
    let z = 120 * cos(phi);
    points.push(createVector(x, y, z));
  }
}

function draw() {
  background(5);

 
  ambientLight(60);
  directionalLight(0, 255, 100, -0.5, 0.5, -1);
  pointLight(0, 255, 0, 0, 0, 300);

  amplitude = mic.getLevel();
  let scaledAmp = floor(amplitude * 1000);
  let binaryStr = scaledAmp.toString(2);


  if (hand) {
    let indexTip = hand.annotations.indexFinger[3];
    let thumbTip = hand.annotations.thumb[3];

    if (indexTip && thumbTip) {
      // Rotation by finger
      let x = indexTip[0];
      let y = indexTip[1];
      rotationY = map(x, 0, width, -PI, PI);
      rotationX = map(y, 0, height, -PI / 2, PI / 2);

      // Zoom with pinch
      let d = dist(indexTip[0], indexTip[1], thumbTip[0], thumbTip[1]);
      let targetZoom = map(d, 20, 200, 0.4, 3);
      zoom = lerp(zoom, targetZoom, 0.1);
    }
  }

  scale(zoom);
  rotateY(rotationY);
  rotateX(rotationX);

  // Draw binary digits
  for (let v of points) {
    push();
    translate(v.x, v.y, v.z);
    fill(0, random(180, 255), 0, 200);
    noStroke();
    text(random([0, 1]), 0, 0);
    pop();
  }

  
  if (amplitude > threshold) {
    for (let i = 0; i < binaryStr.length; i++) {
      if (binaryStr[i] === '1') {
        let theta = random(TWO_PI);
        let phi = random(PI);
        let x1 = 120 * sin(phi) * cos(theta);
        let y1 = 120 * sin(phi) * sin(theta);
        let z1 = 120 * cos(phi);

        let spikeLength = random(80, 200);
        let x2 = x1 + spikeLength * sin(phi) * cos(theta);
        let y2 = y1 + spikeLength * sin(phi) * sin(theta);
        let z2 = z1 + spikeLength * cos(phi);

        strokeWeight(1.5);
        stroke(0, 255, 70, 220);
        line(x1, y1, z1, x2, y2, z2);

    
        push();
        translate(x2, y2, z2);
        fill(0, 255, 0, 200);
        noStroke();
        sphere(5);
        fill(0, 255, 0);
        textSize(10);
        text(nf(amplitude * 10, 1, 3), 0, -15);
        pop();
      }
    }
  }
}