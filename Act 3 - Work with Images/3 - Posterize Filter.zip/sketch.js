let img;

function preload() {
  img = loadImage('schweiz.png');
}

function setup() {
  createCanvas(1000, 1000);
  img.resize(width, height);
  img.filter(POSTERIZE, 4); 
  image(img, 0, 0);
}
