let trail = [];
const maxTrailLength = 30;
const colors = ['#003366', '#800000']; 
let bgColor = '#C0B283'; 

function setup() {
  createCanvas(400, 400);
  background(bgColor);
  noStroke();
}

function draw() {
  fill(red(bgColor), green(bgColor), blue(bgColor), 20);
  rect(0, 0, width, height);

  if (mouseIsPressed || (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height)) {
    trail.push({ x: mouseX, y: mouseY, colorIndex: frameCount % 2 });
  }

  if (trail.length > maxTrailLength) {
    trail.shift();
  }

  // teddy bear shaped trails
  for (let p of trail) {
    push();
    translate(p.x, p.y);
    scale(0.7); // scale teddy size

    fill(colors[p.colorIndex]);
    noStroke();

    // body
    ellipse(0, 10, 30, 40);
    // head
    ellipse(0, -15, 30, 30);
    // ears
    ellipse(-12, -30, 15, 15);
    ellipse(12, -30, 15, 15);
    // arms
    ellipse(-20, 5, 15, 25);
    ellipse(20, 5, 15, 25);
    // legs
    ellipse(-10, 35, 20, 20);
    ellipse(10, 35, 20, 20);

    pop();
  }
}

// Press any key to clear canvas & trail
function keyPressed() {
  background(bgColor);
  trail = [];
}
