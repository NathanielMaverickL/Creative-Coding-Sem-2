function setup() {
  createCanvas(400, 400);
  background('#eadfce');
  noStroke();

  // Big Scoop 
  fill('pink'); 
  ellipse(200, 190, 130, 130);

  // Smaller Scoop 
  fill('lightblue');
  ellipse(200, 125, 90, 90);

  // Cherry 
  fill('red'); 
  ellipse(200, 80, 20, 20);

  // Cone
  fill('#d3af7b'); 
  triangle(145, 240, 255, 240, 200, 370);
}


