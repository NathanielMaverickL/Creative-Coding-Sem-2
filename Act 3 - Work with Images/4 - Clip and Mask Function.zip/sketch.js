let triangleMask;
let myImage;
let maskedImage;

function preload() {
  myImage = loadImage('asset/flower.jpg'); 
}

function setup() {
  createCanvas(400, 400);
  background('#d5cf9b'); 

  triangleMask = createGraphics(128, 128);
  triangleMask.fill(255); 
  triangleMask.noStroke();
  
  triangleMask.triangle(
    64, 0,     
    0, 128,  
    128, 128  
  );

  myImage.resize(128, 128);
  maskedImage = myImage.get();
  maskedImage.mask(triangleMask);
}

function draw() {
  background('#d5cf9b');
  image(maskedImage, 200 - 64, 200 - 64); // center it
}
