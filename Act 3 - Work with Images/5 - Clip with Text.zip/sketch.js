let img;
let overlay;

function preload() {
  img = loadImage('asset/ocean.jpg'); 
}

function setup() {
  createCanvas(400, 400);
  textFont('Georgia');
  textSize(200); // BIGGER text
  textAlign(CENTER, CENTER);

  let overlayMargin = 20;
  let overlayWidth = width - overlayMargin * 2;
  let overlayHeight = height * 0.85;
  let overlayX = overlayMargin;
  let overlayY = (height - overlayHeight) / 2;

  overlay = createGraphics(width, height);
  overlay.fill('#7699bc'); 
  overlay.noStroke();
  overlay.rect(overlayX, overlayY, overlayWidth, overlayHeight); 

  overlay.erase();
  overlay.textSize(200); 
  overlay.text('Hi', width / 2, height / 2); 
  overlay.noErase();
}

function draw() {
  image(img, 0, 0, width, height);
  image(overlay, 0, 0); 
}
