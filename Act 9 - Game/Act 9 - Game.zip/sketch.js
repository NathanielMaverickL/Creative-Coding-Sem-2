let ball;
let paddle;
let score = 0;
let gameOver = false;
let bgImage;

function preload() {
  bgImage = loadImage("asset/blue.png"); 
}

function setup() {
  createCanvas(600, 400);
  ball = new Ball();
  paddle = new Paddle();
  textFont("Helvetica");
}

function draw() {
  background(0);
  image(bgImage, 0, 0, width, height);

  if (!gameOver) {
    ball.update();
    ball.checkPaddle(paddle);
  }

  ball.show();
  paddle.show();

  // Show score
  fill(255);
  stroke(0, 150);
  strokeWeight(2);
  textSize(28);
  textAlign(LEFT, TOP);
  text("Score: " + score, 20, 20);

  if (gameOver) {
    fill(255);
    stroke(0, 200);
    strokeWeight(3);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("Game Over \nFinal Score: " + score, width / 2, height / 2);
    textSize(24);
    text("Refresh to play again!", width / 2, height / 2 + 60);
  }
}

function mouseMoved() {
  if (!gameOver && paddle) {
    paddle.x = constrain(mouseX - paddle.w / 2, 0, width - paddle.w);
  }
}

class Ball {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = width / 2;
    this.y = height / 2;
    this.r = 18;
    this.baseSpeed = 4;
    this.speedMultiplier = 1;
    this.xspeed = random([-1, 1]) * this.baseSpeed * this.speedMultiplier;
    this.yspeed = random(3, 5) * this.speedMultiplier;
  }

  update() {
    this.x += this.xspeed;
    this.y += this.yspeed;

    if (this.x < this.r || this.x > width - this.r) {
      this.xspeed *= -1;
    }

    if (this.y < this.r) {
      this.yspeed *= -1;
    }

    if (this.y > height - this.r) {
      gameOver = true;
    }
  }

  checkPaddle(p) {
    if (
      this.y + this.r >= p.y &&
      this.x > p.x &&
      this.x < p.x + p.w &&
      this.yspeed > 0
    ) {
      this.yspeed *= -1.1; 
      this.xspeed *= 1.05;
      score++;
      this.speedMultiplier = 1 + score * 0.05;
    }
  }

  show() {
    push();
    noStroke();
    for (let r = this.r; r > 0; r -= 3) {
      fill(255, map(r, 0, this.r, 30, 150));
      ellipse(this.x, this.y, r * 2);
    }
    pop();
  }
}

class Paddle {
  constructor() {
    this.w = 120;
    this.h = 20;
    this.x = width / 2 - this.w / 2;
    this.y = height - 40;
  }

  show() {
    push();
    noStroke();
    fill(255, 230);
    rect(this.x, this.y, this.w, this.h, 20);
    pop();
  }
}
