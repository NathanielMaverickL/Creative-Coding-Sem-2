function setup() {
  createCanvas(500, 500);
  noStroke();
  ellipseMode(CENTER);
  rectMode(CENTER);
  colorMode(HSL);
}

function draw() {
  background(230, 30, 10); 

  // stars
  drawStars(80);

  // planets
  drawPlanet(100, 100, 80, color(30, 80, 70));  
  drawPlanet(400, 120, 60, color(200, 80, 70)); 
  drawPlanet(350, 400, 100, color(290, 50, 70)); 

  // ufo base
  drawUFO();

  // Glass dome
  drawGlassDome();

  // Alien head 
  drawAlien();

  noLoop();
}

function drawStars(count) {
  push();
  fill(0, 0, 100, 0.8);
  for(let i = 0; i < count; i++) {
    let x = random(width);
    let y = random(height);
    let size = random(1, 3);
    for(let r = 3; r > 0; r--) {
      fill(60, 100, 100, 0.05 * r);
      ellipse(x, y, size + r * 2);
    }
    fill(60, 100, 100, 0.8);
    ellipse(x, y, size);
  }
  pop();
}

function drawPlanet(x, y, diameter, baseColor) {
  push();
  translate(x, y);

  fill(baseColor);
  ellipse(0, 0, diameter);

  fill(60, 100, 100, 0.3);
  ellipse(-diameter * 0.2, -diameter * 0.2, diameter * 0.5, diameter * 0.5);

  if(baseColor.h > 270) {
    noFill();
    stroke(270, 80, 60, 0.5);
    strokeWeight(5);
    ellipse(0, 0, diameter * 1.3, diameter * 0.4);
  }
  pop();
}

function drawUFO() {
  push();
  translate(width/2, 370);

  let baseGradient = drawingContext.createRadialGradient(0, 0, 50, 0, 0, 140);
  baseGradient.addColorStop(0, '#aaaabb');
  baseGradient.addColorStop(1, '#555566');
  drawingContext.fillStyle = baseGradient;
  ellipse(0, 0, 280, 80);

  fill(200, 20, 80, 0.6);
  ellipse(0, 0, 230, 50);
  pop();
}

function drawGlassDome() {
  push();
  translate(width/2, 260);

  fill(190, 80, 90, 0.15);
  ellipse(0, 0, 220, 150);

  noStroke();
  fill(190, 80, 90, 0.25);
  ellipse(-60, -20, 70, 50);

  drawingContext.shadowColor = 'rgba(135, 206, 235, 0.6)';
  drawingContext.shadowBlur = 20;
  ellipse(0, 0, 220, 150);
  pop();
}

function drawAlien() {
  push();
  translate(width/2, 270);

  // head 
  fill(140, 70, 60);
  ellipse(0, 0, 90, 110);

  // ears 
  fill(140, 70, 60);
  triangle(-45, 0, -65, -30, -40, 30);
  triangle(45, 0, 65, -30, 40, 30);

  // eyes 
  fill(0);
  ellipse(-25, -10, 25, 40);
  ellipse(25, -10, 25, 40);
  fill(255);
  ellipse(-17, -20, 12, 12);
  ellipse(33, -20, 12, 12);

  // mouth 
  noFill();
  stroke(0);
  strokeWeight(3);
  arc(0, 30, 50, 25, 0, PI);
  noStroke();

  pop();
}
