let img;
let palette = ['#8193be', '#81be84', '#e2d991'];

function preload() {
  img = loadImage('schweiz.png');
}

function setup() {
  createCanvas(1000, 1000);
  noLoop();
  img.loadPixels();
}

function draw() {
  background(220);
  image(img, 0, 0); // draw base image first

  let pixelSize = 10;

  for (let y = 0; y < img.height; y += pixelSize) {
    for (let x = 0; x < img.width; x += pixelSize) {
      let c = img.get(x, y);
      let nearest = getNearestColor(color(c));
      nearest.setAlpha(127); // 50% transparency (255 * 0.5)
      fill(nearest);
      noStroke();
      rect(x, y, pixelSize, pixelSize);
    }
  }
}

// Find the closest color from the palette
function getNearestColor(col) {
  let closest;
  let record = 999999;
  for (let hex of palette) {
    let testCol = color(hex);
    let d = dist(red(col), green(col), blue(col), red(testCol), green(testCol), blue(testCol));
    if (d < record) {
      record = d;
      closest = testCol;
    }
  }
  return closest;
}
