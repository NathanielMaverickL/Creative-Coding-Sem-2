let moonX = 0; // starting x-position of the moon

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('navy'); // night sky

  // full moon (moving left to right)
  fill(255);
  stroke(0);
  circle(moonX, 50, 100); // full moon, no shadow

  // move moon across the sky
  moonX += 1;
  if (moonX > width + 50) {
    moonX = -50;
  }

  // gray mountains
  stroke(0);
  fill(80);
  triangle(-40, 300, 75, 100, 250, 300);
  triangle(100, 300, 300, 100, 500, 300);

  // green grass/land
  noStroke();
  fill('rgb(50, 76, 50)');
  rect(0, 300, 400, 100);
}
