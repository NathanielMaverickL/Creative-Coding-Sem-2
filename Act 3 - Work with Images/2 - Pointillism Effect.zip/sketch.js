let img;

function preload() {
  img = loadImage('schweiz.png');
}

function setup() {
  createCanvas(1000, 1000);
  noLoop();
  img.resize(width, height);
  img.loadPixels();
  background(220);
}

function draw() {
  image(img, 0, 0); 

  let spacing = 8;

  noStroke();
  fill(255, 127);

  for (let y = 0; y < height; y += spacing) {
    for (let x = 0; x < width; x += spacing) {
      ellipse(x, y, spacing, spacing);
    }
  }
}