let mic, fft;
let bgImage;

function preload() {
  bgImage = loadImage("asset/bling.png");
}

function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES);
  colorMode(HSB);

  mic = new p5.AudioIn();
  mic.start();

  fft = new p5.FFT(0.9, 128);
  fft.setInput(mic);

  noFill();
}

function draw() {
  background(0);
  image(bgImage, 0, 0, width, height);

  let spectrum = fft.analyze();
  translate(width / 2, height / 2);

  let points = 5; 

  strokeWeight(8);
  stroke(255, 150); 
  noFill();
  beginShape();
  for (let i = 0; i < points * 2; i++) {
    let angle = map(i, 0, points * 2, -90, 270); 
    let index = floor(map(i, 0, points * 2, 0, spectrum.length));
    let radius = map(spectrum[index], 0, 255, 60, 200);
    radius *= (i % 2 === 0) ? 1.4 : 0.6;
    let glowRadius = radius * 1.1;
    let x = glowRadius * cos(angle);
    let y = glowRadius * sin(angle);
    vertex(x, y);
  }
  endShape(CLOSE);

  strokeWeight(4);
  stroke(255);
  noFill();
  beginShape();
  for (let i = 0; i < points * 2; i++) {
    let angle = map(i, 0, points * 2, -90, 270);
    let index = floor(map(i, 0, points * 2, 0, spectrum.length));
    let radius = map(spectrum[index], 0, 255, 60, 200);
    radius *= (i % 2 === 0) ? 1.4 : 0.6;
    let x = radius * cos(angle);
    let y = radius * sin(angle);
    vertex(x, y);
  }
  endShape(CLOSE);

  // --- Colored star on top ---
  strokeWeight(2);
  noFill();
  beginShape();
  for (let i = 0; i < points * 2; i++) {
    let angle = map(i, 0, points * 2, -90, 270);
    let index = floor(map(i, 0, points * 2, 0, spectrum.length));
    let radius = map(spectrum[index], 0, 255, 60, 200);
    radius *= (i % 2 === 0) ? 1.4 : 0.6;
    let x = radius * cos(angle);
    let y = radius * sin(angle);
    let hue = map(index, 0, spectrum.length, 260, 310);
    stroke(hue, 100, 100);
    vertex(x, y);
  }
  endShape(CLOSE);
}
