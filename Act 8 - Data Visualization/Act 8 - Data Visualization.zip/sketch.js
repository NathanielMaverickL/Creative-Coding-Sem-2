let countries = ["Germany", "France", "UK", "Italy", "Spain", "Poland", "Netherlands"];
let population = [83.2, 67.8, 66.0, 59.1, 47.5, 37.8, 17.4]; // in millions
let barColors = [];
let bgImage;

function preload() {
  bgImage = loadImage("asset/blue.png");
}

function setup() {
  createCanvas(800, 500);
  colorMode(HSB);
  textFont("Georgia");
  textAlign(CENTER, CENTER);

  for (let i = 0; i < countries.length; i++) {
    barColors[i] = color(map(i, 0, countries.length, 180, 300), 50, 90);
  }
}

function draw() {
  background(0);
  image(bgImage, 0, 0, width, height);

  fill(255); // white text
  textSize(24);
  text("Population of European Countries (in millions)", width / 2, 30);

  let margin = 80;
  let barWidth = (width - 2 * margin) / countries.length;
  let maxPop = max(population);

  for (let i = 0; i < countries.length; i++) {
    let x = margin + i * barWidth;
    let barHeight = map(population[i], 0, maxPop, 0, height - 150);
    let y = height - 60 - barHeight;

    // Bar color and hover
    if (mouseX > x && mouseX < x + barWidth && mouseY > y && mouseY < y + barHeight) {
      fill(barColors[i]);
      stroke(255);
      strokeWeight(1);
      rect(x, y, barWidth - 10, barHeight);
      noStroke();
      fill(255); 
      textSize(16);
      text(`${population[i]}M`, x + barWidth / 2 - 5, y - 15);
    } else {
      fill(barColors[i]);
      noStroke();
      rect(x, y, barWidth - 10, barHeight);
    }

    // Labels
    fill(255);
    textSize(14);
    text(countries[i], x + barWidth / 2 - 5, height - 30);
  }
}
